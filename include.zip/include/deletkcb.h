#ifndef deletkcbsj.h
#define deletkcbsj.h

void deletkcb(char a[],int daynum1,int classnum1,int weeknum);
void drawdelet();
#endif

