#ifndef _yulan_h_
#define _yulan_h_

#include"test.h"

void tiaoz(class*);
void yulanjm(class*x,int week);

#endif
