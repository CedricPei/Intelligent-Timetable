#ifndef_zhuce1_h
#define_zhuce1_h

void zhuce1();
void hjm();
#endif
