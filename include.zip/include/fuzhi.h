#ifndef _fuzhi_h_
#define _fuzhi_h_

#include"test.h"

void fuzhi(class*aia,class*jx,class*gd,class*sk,class*ch,char **pbc);

#endif
