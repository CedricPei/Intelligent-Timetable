#ifndef _chaxun_h_
#define _chaxun_h_

#include"test.h"

void cxmode(int ,class*,int*,int*);
void datecx(class*,int*,int*);
void draw(void);
void classcx(class*);
void huajiemian(int ,class*);

#endif
