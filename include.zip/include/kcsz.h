#ifndef _kcsz_h_
#define _kcsz_h_

void kcsz(int num);
void ksjm();
void circle_but(int x,int y,char* c);
void changecolor(int x,int y);
void draw_butten();
int choose_col(void* box, int colnum);
#endif
