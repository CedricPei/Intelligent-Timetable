#ifndef _select_h_
#define _select_h_
#include"test.h"

int tcsel(int a,tec *cl,char*n,class*x,int nownum);

#endif
