#ifndef _openpage_h_
#define _openpage_h_

void openpage(void);

#endif