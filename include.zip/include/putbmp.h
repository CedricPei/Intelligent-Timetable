#ifndef _putbmp_H
#define _putbmp_H

int putbmp(int x, int y, char *s);

#endif
