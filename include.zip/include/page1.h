#ifndef _page1_h_
#define _page1_h_

void firstpage(int*);
void btn_stu(void);
void btn_tc(void);
//void btn_game(void);
void btn_exit(void);
void lightbtn(int*);


#endif
