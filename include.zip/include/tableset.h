#ifndef _tableset_h_
#define _tableset_h_

void tableset(int);
void modify(char *);
int choose_location(char *a);

#endif