#ifndef_GNXZ_h 
#define_GNXZ_h 

void gnxz(int num);
void xzjm();
void xz(int num);
#endif

