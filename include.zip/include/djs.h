#ifndef __djs_h__
#define __djs_h__

void djs(int num);
void hjm2();
void time2();
void szjm();
void sz(char bnum,char a[][30],int num);
int year_daycha(int year1, int year2);
int day_js(int year, int month, int day);
int daycha(char* year, char* month, char* day);
void xstime(char c, char* mc, char* year1, char* mon1, char* day1);
void deletbutton(int x,int y);
void clickdel(char n,int num,char a[][30]);
#endif

