#ifndef _SEARCH_H_
#define _SEARCH_H_

#include"test.h"

void search(class *x);
void page1(int *week,int *day);
void page2(int *week,int *day,class *x);
int limit(int month);

#endif
