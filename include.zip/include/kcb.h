#ifndef _kcb_h_
#define _kcb_h_

void kcb(int num);
void draw2(void);
void draw_search();
void gettime1();
void draw_plus(int x, int y);
void draw_time(int num);
void search_class(int num,char*a);
void draw_sc();
int butten_choose();
void show_inform(char*a, int daynum1, int classnum1, int weeknum);
#endif
