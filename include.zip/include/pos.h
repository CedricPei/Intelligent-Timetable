#ifndef _pos_h_
#define _pos_h_
#include"test.h"

void pos(class*,int,int *,int *);
void changep(int *); 

#endif
