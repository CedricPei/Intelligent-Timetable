#ifndef _choose_h_
#define _choose_h_

void choose(int,int*,int*);

#endif
