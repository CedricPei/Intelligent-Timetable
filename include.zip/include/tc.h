#ifndef _tc_h_
#define _tc_h_

#include"test.h"
void tcmode(class*,class*,class*,class*,class*,char**);
void viewinit(void);

void initjl(int jl[],int n);


#endif
