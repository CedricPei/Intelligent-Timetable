#ifndef _addclass_h_
#define _addclass_h_

#include"test.h"

void addclass(class*);
void addview(class*);

#endif
