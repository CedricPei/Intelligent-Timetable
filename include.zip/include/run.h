#ifndef _run_h_
#define _run_h_

#include"test.h"

void runmode(class*,int);
void drawkcb(class*,int,int,int);

#endif
